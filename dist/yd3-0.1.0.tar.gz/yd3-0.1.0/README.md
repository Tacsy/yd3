# yd3
command line dictionary to get bilingual dictionary on hand
